import { NextResponse } from 'next/server';
import { withDB } from '@/lib/mongodb';
import { verifySession } from '@/lib/dal';
import { sendTemplateMessage } from '@/lib/whatsapp';
import Contact from '@/models/Contact';
import Broadcast from '@/models/Broadcast';
import Tenant from '@/models/Tenant';

export async function POST(req) {
  const session = await verifySession();
  await withDB();

  const { broadcastId } = await req.json();
  const broadcast = await Broadcast.findOne({ _id: broadcastId, tenantId: session.tenantId });
  if (!broadcast) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  const tenant = await Tenant.findById(session.tenantId);

  const query = { tenantId: session.tenantId, optedOut: false };
  if (broadcast.targetTags?.length) query.tags = { $in: broadcast.targetTags };

  const contacts = await Contact.find(query).lean();

  await Broadcast.findByIdAndUpdate(broadcastId, {
    status: 'running',
    'stats.total': contacts.length,
  });

  let sent = 0, failed = 0;
  for (const contact of contacts) {
    try {
      await sendTemplateMessage(
        tenant.phoneNumberId,
        contact.phone,
        broadcast.templateName,
        'en',
        [],
        tenant.accessToken
      );
      sent++;
    } catch {
      failed++;
    }
  }

  await Broadcast.findByIdAndUpdate(broadcastId, {
    status: 'completed',
    'stats.sent': sent,
    'stats.failed': failed,
  });

  return NextResponse.json({ sent, failed, total: contacts.length });
}
