'use client';

import { useState, useEffect, useCallback } from 'react';

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    businessName: '',
    wabaId: '',
    phoneNumberId: '',
    accessToken: '',
    verifiedName: '',
    waConnected: false,
    plan: 'free',
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [connectMsg, setConnectMsg] = useState('');

  const loadSettings = useCallback(() => {
    fetch('/api/settings').then((r) => r.json()).then((d) => {
      if (d._id) setSettings((prev) => ({ ...prev, ...d }));
    });
  }, []);

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  // Load Facebook SDK for embedded signup
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (document.getElementById('facebook-jssdk')) return;
    window.fbAsyncInit = function () {
      window.FB.init({ appId: process.env.NEXT_PUBLIC_META_APP_ID, autoLogAppEvents: true, xfbml: true, version: 'v19.0' });
    };
    const script = document.createElement('script');
    script.id = 'facebook-jssdk';
    script.src = 'https://connect.facebook.net/en_US/sdk.js';
    script.async = true;
    script.defer = true;
    document.body.appendChild(script);
  }, []);

  async function save(e) {
    e.preventDefault();
    setSaving(true);
    await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    setSaving(false);
    setSaved(true);
    loadSettings();
    setTimeout(() => setSaved(false), 2000);
  }

  function launchEmbeddedSignup() {
    if (!window.FB) {
      alert('Facebook SDK is still loading. Please try again in a moment.');
      return;
    }
    setConnecting(true);
    setConnectMsg('');

    window.FB.login(
      async (response) => {
        if (response.authResponse?.code) {
          try {
            const res = await fetch('/api/meta/embedded-signup', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ code: response.authResponse.code }),
            });
            const data = await res.json();
            if (data.error) {
              setConnectMsg('Error: ' + data.error);
            } else {
              setConnectMsg('WhatsApp connected successfully!');
              loadSettings();
            }
          } catch {
            setConnectMsg('Something went wrong. Please try again.');
          }
        } else {
          setConnectMsg('Login cancelled or failed.');
        }
        setConnecting(false);
      },
      {
        config_id: process.env.NEXT_PUBLIC_META_CONFIG_ID || '',
        response_type: 'code',
        override_default_response_type: true,
        extras: { setup: {}, featureType: '', sessionInfoVersion: '3' },
      }
    );
  }

  const inputCls = "w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#25D366] focus:bg-white text-sm transition-colors";

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h2 className="text-lg font-bold text-slate-900">Settings</h2>
        <p className="text-slate-500 text-sm">Configure your WhatsApp Business API connection</p>
      </div>

      {/* WhatsApp Connection Status */}
      <div className={`rounded-xl p-5 border ${settings.waConnected ? 'bg-green-50 border-green-200' : 'bg-slate-50 border-slate-200'}`}>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full shrink-0 ${settings.waConnected ? 'bg-[#25D366] animate-pulse' : 'bg-slate-300'}`} />
            <div>
              <p className={`font-semibold ${settings.waConnected ? 'text-green-800' : 'text-slate-700'}`}>
                {settings.waConnected ? 'WhatsApp Connected' : 'WhatsApp Not Connected'}
              </p>
              {settings.waConnected && settings.verifiedName && (
                <p className="text-green-700 text-sm">{settings.verifiedName} · {settings.phoneNumberId}</p>
              )}
            </div>
          </div>
          <button
            onClick={launchEmbeddedSignup}
            disabled={connecting}
            className="flex items-center gap-2 px-4 py-2 bg-[#1877F2] hover:bg-[#166fe5] disabled:opacity-60 text-white rounded-xl text-sm font-semibold transition-colors shadow-sm"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
            {connecting ? 'Connecting...' : settings.waConnected ? 'Reconnect via Meta' : 'Connect via Meta'}
          </button>
        </div>
        {connectMsg && (
          <p className={`text-sm mt-3 font-medium ${connectMsg.includes('success') ? 'text-green-700' : 'text-red-600'}`}>
            {connectMsg}
          </p>
        )}
        {!settings.waConnected && (
          <p className="text-slate-500 text-xs mt-3">
            Use the Meta Embedded Signup above to instantly connect your WhatsApp Business Account — no manual copy-paste of tokens needed.
          </p>
        )}
      </div>

      <form onSubmit={save} className="space-y-6">
        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4 shadow-sm">
          <h3 className="font-semibold text-slate-900">Business Information</h3>
          <div>
            <label className="block text-sm text-slate-600 mb-1.5">Business Name</label>
            <input
              type="text"
              value={settings.businessName}
              onChange={(e) => setSettings({ ...settings, businessName: e.target.value })}
              className={inputCls}
            />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4 shadow-sm">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-slate-900">WhatsApp Cloud API (Manual)</h3>
            <a
              href="https://developers.facebook.com/docs/whatsapp/cloud-api/get-started"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-[#25D366] hover:underline"
            >
              Setup guide ↗
            </a>
          </div>
          <p className="text-slate-400 text-xs">Only needed if you prefer to connect manually instead of using the Meta Embedded Signup above.</p>

          {[
            { key: 'wabaId', label: 'WhatsApp Business Account ID', placeholder: '123456789012345' },
            { key: 'phoneNumberId', label: 'Phone Number ID', placeholder: '987654321098765' },
            { key: 'verifiedName', label: 'Verified Business Name', placeholder: 'Your Business Name' },
          ].map((field) => (
            <div key={field.key}>
              <label className="block text-sm text-slate-600 mb-1.5">{field.label}</label>
              <input
                type="text"
                value={settings[field.key]}
                onChange={(e) => setSettings({ ...settings, [field.key]: e.target.value })}
                placeholder={field.placeholder}
                className={inputCls}
              />
            </div>
          ))}

          <div>
            <label className="block text-sm text-slate-600 mb-1.5">Permanent Access Token</label>
            <input
              type="password"
              value={settings.accessToken}
              onChange={(e) => setSettings({ ...settings, accessToken: e.target.value })}
              placeholder="EAAxxxxxxxx..."
              className={inputCls}
            />
            <p className="text-slate-400 text-xs mt-1">Your permanent token from Meta Business Settings → System Users</p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <h3 className="font-semibold text-slate-900 mb-3">Webhook Configuration</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">Webhook URL (configure in Meta)</label>
              <div className="flex items-center gap-2 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[#25D366] text-sm font-mono truncate">
                  {typeof window !== 'undefined' ? window.location.origin : 'https://yourdomain.com'}/api/webhook/whatsapp
                </span>
              </div>
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Verify Token (set META_VERIFY_TOKEN in .env)</label>
              <div className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-600 text-sm">
                {process.env.NEXT_PUBLIC_META_VERIFY_TOKEN || 'your_custom_webhook_verify_token'}
              </div>
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3 bg-[#25D366] hover:bg-[#128C7E] disabled:opacity-60 text-white font-semibold rounded-xl transition-colors shadow-sm"
        >
          {saving ? 'Saving...' : saved ? '✓ Saved!' : 'Save Settings'}
        </button>
      </form>
    </div>
  );
}
